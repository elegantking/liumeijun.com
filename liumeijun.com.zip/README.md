Hello Meijun!
=============

这个是 2012 年送给我女朋友的生日礼物，你可以直接访问 [http://liumeijun.com/](http://liumeijun.com/) 来查看这个项目的效果。

项目的全部源代码都已经上传至 Github，你们可以自由的查看和修改。

PS: 项目内的图片文件已经托管到了七牛云存储加速。
